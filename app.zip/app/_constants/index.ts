export const MEMBERS_LIST_LIMIT = 100;
export const TOP_NEWS_LIMIT = 2;
export const NEWS_LIST_LIMIT = 10;